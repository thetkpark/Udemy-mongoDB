import React from 'react';

const Switch = () => {
  return (
    <div>
      Switch
    </div>
  );
};

export { Switch };
