const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AlbumSchema = new Schema({
  title: String,
  data: Date,
  copiesSolid: Number,
  numberTracks: Number,
  image: String,
  revenue: Number

});

module.export = AlbumSchema;
